// --- Web Audio Synthesizer ---
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function playHurtSound() {
    if (selectedCharacter === 'kitty') {
        playCatSound();
    } else {
        playGirlHurt();
    }
}

// Kitty death: the real cat sound file (game/assets/audio/cat.ogg).
let catSound;
function playCatSound() {
    if (!catSound) {
        catSound = new Audio('../assets/audio/cat.ogg');
        catSound.volume = 0.85;
    }
    catSound.currentTime = 0;
    const p = catSound.play();
    if (p) p.catch(() => {});
}

// Explorer girl death: a girl voice says "Јао!" in Serbian (sr-RS).
function playGirlHurt() {
    // Prefer the project's shared pre-generated speech MP3s (speech.speak).
    try {
        if (window.speech && typeof window.speech.speak === 'function') {
            window.speech.speak('Јао!', function () {});
            return;
        }
    } catch (e) { /* fall through */ }

    // If shared speech is not available, try native speechSynthesis.
    try {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const u = new SpeechSynthesisUtterance('Јао!');
            u.lang = 'sr-RS';
            u.rate = 0.9;
            u.pitch = 1.1;
            window.speechSynthesis.speak(u);
            return;
        }
    } catch (e) {
        // fall through to WebAudio fallback
    }

    // WebAudio fallback: short vowel/exclamation synth (best-effort)
    try {
        if (!audioCtx) audioCtx = new AudioContext();
        const now = audioCtx.currentTime;
        // two-oscillator short exclamation, descending pitch
        const o1 = audioCtx.createOscillator();
        const o2 = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        const filt = audioCtx.createBiquadFilter();
        filt.type = 'bandpass';
        filt.frequency.value = 800;
        o1.type = 'sawtooth';
        o2.type = 'sine';
        o1.frequency.setValueAtTime(700, now);
        o1.frequency.exponentialRampToValueAtTime(240, now + 0.35);
        o2.frequency.setValueAtTime(1200, now);
        o2.frequency.exponentialRampToValueAtTime(360, now + 0.35);
        g.gain.setValueAtTime(0.0001, now);
        g.gain.linearRampToValueAtTime(0.22, now + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
        o1.connect(filt); o2.connect(filt); filt.connect(g); g.connect(audioCtx.destination);
        o1.start(now); o2.start(now);
        o1.stop(now + 0.6); o2.stop(now + 0.6);
    } catch (e) {
        // Give up silently if audio can't be created.
    }
}

function initAudio() {
    if (!audioCtx) {
        audioCtx = new AudioContext();
        if (musicTheme) startMusic(musicTheme);
    }
}

// Best-effort: resume/init audio on first user pointerdown so music/TTS will work on
// touch devices without further interaction. This respects browser autoplay rules and
// provides a single, natural gesture children can perform.
window.addEventListener('pointerdown', function _firstAudioGesture() {
    try { initAudio(); if (musicTheme && musicOn) startMusic(musicTheme); } catch (e) { }
}, { once: true, passive: true });

function playSound(type) {
    if (!audioCtx) return;
    const now = audioCtx.currentTime;

    if (type === 'jump') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(200, now);
        osc.frequency.exponentialRampToValueAtTime(500, now + 0.12);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.12);
        osc.start(now);
        osc.stop(now + 0.12);
    } else if (type === 'coin') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(987.77, now); // B5
        osc.frequency.setValueAtTime(1318.51, now + 0.08); // E6
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.22);
        osc.start(now);
        osc.stop(now + 0.22);
    } else if (type === 'win') {
        const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
        notes.forEach((freq, idx) => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);

            const start = now + (idx * 0.07);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, start);

            gain.gain.setValueAtTime(0, start);
            gain.gain.linearRampToValueAtTime(0.2, start + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.12);

            osc.start(start);
            osc.stop(start + 0.12);
        });
    } else if (type === 'pop') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'square';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(420, now + 0.05);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.07);
    }
}

// --- Procedural Background Music (offline, per-world themes) ---
// Each world plays a slow 4-bar loop (32 melody steps + 16-beat bass) plus a
// world-specific ambient sound layer (birds, wind, drips, bubbles, bells...).
// Root/scale/tempo/ambient are chosen to match the world's place and mood —
// all synthesized with Web Audio, no external audio files.
const MUSIC = {
    spring: {
        root: 523.25, bpm: 100, wave: 'sine', vol: 0.10,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-7,-7,-7,-7],
        seq:  [0,4,7,9,7,4,2,4, 0,4,7,12,9,7,4,2, 7,9,12,14,12,9,7,4, 2,4,7,9,4,2,0,null],
        ambient: { sound: 'bird', rate: 0.05, vol: 0.045 }
    },
    summer: {
        root: 587.33, bpm: 88, wave: 'triangle', vol: 0.09,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12],
        seq:  [0,4,7,9,12,9,7,4, 0,4,7,9,7,4,2,4, 9,12,14,16,14,12,9,7, 4,7,9,12,9,7,4,2],
        ambient: { sound: 'cricket', rate: 0.08, vol: 0.03 }
    },
    autumn: {
        root: 440.00, bpm: 72, wave: 'sine', vol: 0.10,
        bass: [-12,-12,-12,-12,-16,-16,-16,-16,-14,-14,-14,-14,-16,-16,-16,-16],
        seq:  [0,2,3,5,7,5,3,2, 0,null,3,5,7,8,7,5, 3,5,7,8,10,8,7,5, 3,2,3,5,2,null,0,null],
        ambient: { sound: 'rustle', rate: 0.06, vol: 0.05 }
    },
    winter: {
        root: 523.25, bpm: 84, wave: 'triangle', vol: 0.08,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12],
        seq:  [12,16,19,16,12,16,19,21, 16,19,21,24,19,16,12,16, 19,21,24,28,24,21,19,16, 12,16,19,21,19,16,14,16],
        ambient: { sound: 'wind', rate: 0.06, vol: 0.035 }
    },
    underground: {
        root: 329.63, bpm: 66, wave: 'sine', vol: 0.11,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12],
        seq:  [0,3,5,7,5,3,0,null, 0,3,5,3,7,5,3,0, 0,3,5,7,10,7,5,3, 5,3,0,null,3,0,null,null],
        ambient: { sound: 'rumble', rate: 0.05, vol: 0.05 }
    },
    cave: {
        root: 196.00, bpm: 58, wave: 'sine', vol: 0.11,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12],
        seq:  [0,null,3,null,5,null,3,0, null,null,5,null,7,5,3,null, 0,null,3,null,5,3,0,null, null,5,7,10,7,5,3,0],
        ambient: { sound: 'drip', rate: 0.10, vol: 0.06 }
    },
    water: {
        root: 349.23, bpm: 70, wave: 'sine', vol: 0.10,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-5,-5,-5,-5,-12,-12,-12,-12],
        seq:  [0,4,7,9,12,9,7,4, 0,4,7,12,14,12,9,7, 4,7,9,14,12,9,7,4, 0,4,7,9,12,9,7,4],
        ambient: { sound: 'bubble', rate: 0.12, vol: 0.04 }
    },
    savanna: {
        root: 440.00, bpm: 84, wave: 'triangle', vol: 0.09,
        bass: [-12,-12,-12,-12,-5,-5,-5,-5,-12,-12,-12,-12,-5,-5,-5,-5],
        seq:  [0,2,4,7,9,7,4,2, 4,7,9,12,9,7,4,2, 0,2,4,7,12,9,7,4, 2,4,7,9,4,2,0,null],
        ambient: { sound: 'coo', rate: 0.07, vol: 0.05 }
    },
    japan: {
        root: 440.00, bpm: 76, wave: 'sine', vol: 0.10,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12],
        seq:  [0,3,7,8,7,3,0,null, 0,3,7,12,8,7,3,0, 3,7,8,7,3,0,null,3, 0,3,7,8,12,8,7,3],
        ambient: { sound: 'flute', rate: 0.09, vol: 0.06 }
    },
    northpole: {
        root: 659.25, bpm: 96, wave: 'triangle', vol: 0.07,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12],
        seq:  [12,16,19,16,12,16,19,21, 16,19,21,24,21,19,16,12, 19,16,12,16,19,21,19,16, 12,16,19,24,21,19,16,19],
        ambient: { sound: 'bell', rate: 0.06, vol: 0.035 }
    },
    egypt: {
        root: 329.63, bpm: 78, wave: 'sine', vol: 0.10,
        bass: [-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-12,-17,-17,-17,-17],
        seq:  [0,1,4,5,7,5,4,1, 0,4,5,7,8,7,5,4, 0,1,4,7,8,10,8,7, 5,4,1,0,4,1,0,null],
        ambient: { sound: 'desert', rate: 0.06, vol: 0.05 }
    }
};

let musicTheme = null;
let musicStep = 0;
let musicStepTime = 0;
let musicTimer = null;
let musicOn = localStorage.getItem('pkMusic') !== 'off';

function setMusicOn(on) {
    musicOn = on;
    localStorage.setItem('pkMusic', on ? 'on' : 'off');
    const btn = document.getElementById('music-btn');
    if (btn) {
        btn.textContent = on ? '🔊' : '🔇';
        btn.classList.toggle('off', !on);
    }
    if (on) startMusic(musicTheme);
    else stopMusic();
}

function stopMusic() {
    if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
}

function startMusic(themeKey) {
    if (!MUSIC[themeKey]) return;
    musicTheme = themeKey;
    if (!musicOn || !audioCtx) return;
    stopMusic();
    musicStep = 0;
    musicStepTime = audioCtx.currentTime + 0.08;
    musicTimer = setInterval(musicTick, 120);
}

function noteFreq(root, semi) {
    return root * Math.pow(2, semi / 12);
}

function musicTick() {
    if (!audioCtx || !musicOn || paused) return;
    const cfg = MUSIC[musicTheme];
    if (!cfg) return;
    const eighth = 60 / cfg.bpm / 2;
    const horizon = audioCtx.currentTime + 0.35;
    while (musicStepTime < horizon) {
        scheduleStep(cfg, musicStep, musicStepTime, eighth);
        musicStep++;
        musicStepTime += eighth;
    }
}

function scheduleStep(cfg, step, t, eighth) {
    const mel = cfg.seq[step % cfg.seq.length];
    if (mel !== null && mel !== undefined) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = cfg.wave;
        osc.frequency.value = noteFreq(cfg.root, mel);
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(cfg.vol, t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, t + eighth * 0.9);
        osc.start(t);
        osc.stop(t + eighth * 0.95);
    }
    if (step % 2 === 0) {
        const bassIdx = (step / 2) % cfg.bass.length;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.value = noteFreq(cfg.root, cfg.bass[bassIdx]);
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(cfg.vol * 0.7, t + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, t + eighth * 1.8);
        osc.start(t);
        osc.stop(t + eighth * 1.85);
    }
    const amb = cfg.ambient;
    if (amb && Math.random() < amb.rate) {
        playAmbient(amb.sound, amb.vol, t);
    }
}

function makeNoiseBuffer(dur) {
    const b = audioCtx.createBuffer(1, Math.ceil(audioCtx.sampleRate * dur), audioCtx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return b;
}
let noiseBuf = null;

function playAmbient(type, vol, t) {
    switch (type) {
        case 'bird': ambBird(vol, t); break;
        case 'cricket': ambCricket(vol, t); break;
        case 'wind': ambWind(vol, t, 1.6, 900); break;
        case 'rustle': ambRustle(vol, t); break;
        case 'rumble': ambWind(vol, t, 2.4, 200); break;
        case 'drip': ambDrip(vol, t); break;
        case 'bubble': ambBubble(vol, t); break;
        case 'flute': ambFlute(vol, t); break;
        case 'bell': ambBell(vol, t); break;
        case 'coo': ambCoo(vol, t); break;
        case 'desert': ambDesert(vol, t); break;
    }
}

function ambBird(vol, t) {
    for (let k = 0; k < 3; k++) {
        const t0 = t + k * 0.16;
        const base = 2200 + Math.random() * 1400;
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.connect(g); g.connect(audioCtx.destination);
        o.type = 'sine';
        o.frequency.setValueAtTime(base, t0);
        o.frequency.exponentialRampToValueAtTime(base * 1.4, t0 + 0.05);
        o.frequency.exponentialRampToValueAtTime(base * 0.9, t0 + 0.09);
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(vol, t0 + 0.01);
        g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.1);
        o.start(t0); o.stop(t0 + 0.11);
    }
}

function ambCricket(vol, t) {
    for (let k = 0; k < 4; k++) {
        const t0 = t + k * 0.09;
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.connect(g); g.connect(audioCtx.destination);
        o.type = 'sine';
        o.frequency.value = 4300;
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(vol * 0.6, t0 + 0.005);
        g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.05);
        o.start(t0); o.stop(t0 + 0.06);
    }
}

function ambWind(vol, t, dur, freq) {
    if (!noiseBuf) noiseBuf = makeNoiseBuffer(2);
    const src = audioCtx.createBufferSource();
    src.buffer = noiseBuf;
    src.loop = true;
    const f = audioCtx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = freq || 500;
    const g = audioCtx.createGain();
    src.connect(f); f.connect(g); g.connect(audioCtx.destination);
    const d = dur || 1.5;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + d * 0.35);
    g.gain.linearRampToValueAtTime(0, t + d);
    src.start(t); src.stop(t + d + 0.05);
}

function ambRustle(vol, t) {
    if (!noiseBuf) noiseBuf = makeNoiseBuffer(2);
    for (let k = 0; k < 3; k++) {
        const src = audioCtx.createBufferSource();
        src.buffer = noiseBuf;
        src.loop = true;
        const f = audioCtx.createBiquadFilter();
        f.type = 'highpass';
        f.frequency.value = 1800 + Math.random() * 1400;
        const g = audioCtx.createGain();
        src.connect(f); f.connect(g); g.connect(audioCtx.destination);
        const t0 = t + k * (0.1 + Math.random() * 0.15);
        const d = 0.12 + Math.random() * 0.1;
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(vol, t0 + 0.02);
        g.gain.linearRampToValueAtTime(0, t0 + d);
        src.start(t0); src.stop(t0 + d + 0.05);
    }
}

function ambDrip(vol, t) {
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.type = 'sine';
    o.frequency.setValueAtTime(900 + Math.random() * 300, t);
    o.frequency.exponentialRampToValueAtTime(180, t + 0.14);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
    o.start(t); o.stop(t + 0.2);
}

function ambBubble(vol, t) {
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.type = 'sine';
    const f0 = 250 + Math.random() * 300;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f0 * 2.2, t + 0.12);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
    o.start(t); o.stop(t + 0.15);
}

function ambFlute(vol, t) {
    const notes = [0, 7, 12, 7];
    notes.forEach((semi, i) => {
        const t0 = t + i * 0.32;
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.connect(g); g.connect(audioCtx.destination);
        o.type = 'sine';
        o.frequency.value = noteFreq(440, semi);
        const lfo = audioCtx.createOscillator();
        const lg = audioCtx.createGain();
        lfo.connect(lg);
        lg.connect(o.frequency);
        lg.gain.value = 4;
        lfo.frequency.value = 5.5;
        lfo.start(t0); lfo.stop(t0 + 0.5);
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(vol, t0 + 0.05);
        g.gain.linearRampToValueAtTime(vol * 0.7, t0 + 0.2);
        g.gain.linearRampToValueAtTime(0, t0 + 0.55);
        o.start(t0); o.stop(t0 + 0.6);
    });
}

function ambBell(vol, t) {
    [0, 7, 12].forEach((semi) => {
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.connect(g); g.connect(audioCtx.destination);
        o.type = 'triangle';
        o.frequency.value = noteFreq(659.25, semi);
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(vol, t + 0.01);
        g.gain.exponentialRampToValueAtTime(0.001, t + 1.2);
        o.start(t); o.stop(t + 1.3);
    });
}

function ambCoo(vol, t) {
    [0, -2].forEach((semi, i) => {
        const t0 = t + i * 0.14;
        const o = audioCtx.createOscillator();
        const g = audioCtx.createGain();
        o.connect(g); g.connect(audioCtx.destination);
        o.type = 'sine';
        o.frequency.value = 440 * Math.pow(2, semi / 12) * 0.5;
        g.gain.setValueAtTime(0, t0);
        g.gain.linearRampToValueAtTime(vol, t0 + 0.03);
        g.gain.linearRampToValueAtTime(0, t0 + 0.18);
        o.start(t0); o.stop(t0 + 0.2);
    });
}

function ambDesert(vol, t) {
    ambWind(vol, t, 1.8, 420);
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.connect(g); g.connect(audioCtx.destination);
    o.type = 'sine';
    o.frequency.value = 110;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol * 0.7, t + 0.5);
    g.gain.linearRampToValueAtTime(0, t + 1.8);
    o.start(t); o.stop(t + 1.9);
}

// --- Canvas Setup ---
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
let coinCount = 0;
let worldLoaded = false;

function resizeCanvas() {
    const oldH = canvas.height;
    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;
    if (!worldLoaded || Math.abs(canvas.height - oldH) < 2) return;
    const dy = canvas.height - oldH;
    groundY += dy;
    platforms.forEach(p => { p.y += dy; });
    movingPlatforms.forEach(mp => { mp.y += dy; });
    pipes.forEach(pp => { pp.y += dy; });
    coins.forEach(c => { c.y += dy; });
    if (goal) goal.y += dy;
    mice.forEach(m => { m.pipeY += dy; m.hiddenY += dy; m.visibleY += dy; m.y += dy; });
    walkers.forEach(w => { w.y += dy; });
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// --- Input Controls ---
const keys = { left: false, right: false, jump: false };

function bindButton(id, keyProp) {
    const el = document.getElementById(id);
    const start = (e) => {
        e.preventDefault();
        initAudio();
        keys[keyProp] = true;
    };
    const end = (e) => {
        e.preventDefault();
        keys[keyProp] = false;
    };
    el.addEventListener('touchstart', start, {passive: false});
    el.addEventListener('touchend', end, {passive: false});
    el.addEventListener('mousedown', start);
    el.addEventListener('mouseup', end);
    el.addEventListener('mouseleave', end);
}

bindButton('btn-left', 'left');
bindButton('btn-right', 'right');
bindButton('btn-jump', 'jump');

window.addEventListener('keydown', (e) => {
    const isGameKey = e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.code === 'Space' || e.key === 'ArrowUp' || e.key === 'a' || e.key === 'd' || e.key === 'w';
    if (isGameKey) e.preventDefault();
    initAudio();
    if (e.key === 'ArrowLeft' || e.key === 'a') keys.left = true;
    if (e.key === 'ArrowRight' || e.key === 'd') keys.right = true;
    if (e.key === 'ArrowUp' || e.code === 'Space' || e.key === 'w') keys.jump = true;
});
window.addEventListener('keyup', (e) => {
    if (e.key === 'ArrowLeft' || e.key === 'a') keys.left = false;
    if (e.key === 'ArrowRight' || e.key === 'd') keys.right = false;
    if (e.key === 'ArrowUp' || e.code === 'Space' || e.key === 'w') keys.jump = false;
});

// --- World data (11 worlds, data-driven) ---
// Fields per world:
//   name, collectible (emoji), enemy (pop-out type), walker (ground-walker type),
//   goal (goal building type), music,
//   colors, isNight, decor, noClouds, ceiling(+ceilingColor),
//   grounds [{x,width}], floats [{x,width,dy,color}], moves [{x,width,dy,minX,maxX,vx,color}],
//   pipes [{x,height}], walkers [{x,range}] (patrol [x, x+range] on the ground),
//   coins [{x,dy}], goalX.
// Four layout patterns (so levels feel different):
//   A "islands"     — separated islands, one float per gap (Spring, Summer)
//   B "towers"      — long runs with tall stacked floats (Autumn, Winter, Japan)
//   C "tunnels"     — short ledges, low dense hops + rock ceiling (Underground, Cave, Water)
//   D "long run"    — long flat ground, very sparse floats (Savanna, North Pole, Egypt)
const WORLDS = [
  {
    name: 'Пролећни дан', collectible: '🍓', enemy: 'mouse', goal: 'house', music: 'spring', pitHazard: 'water',
    walker: 'ladybug',
    bgSky: '#5c94fc', groundColor: '#70c838', hillColor: '#00a800', pipeColor: '#00a800',
    stairColor: '#4f9a24',
    isNight: false, decor: null, noClouds: false,
    stairs: [{x:2450,peak:3,w:56,h:40},{x:4000,peak:4,w:56,h:40}],
    grounds: [{x:0,w:500},{x:800,w:450},{x:1500,w:500},{x:2300,w:450},{x:3100,w:500},{x:3900,w:500},{x:4700,w:900}],
    floats: [
      {x:600,dy:110,w:150,color:'#f8b800'},{x:1370,dy:120,w:140,color:'#f83800'},
      {x:2100,dy:100,w:150,color:'#f8b800'},{x:2900,dy:130,w:160,color:'#f83800'},
      {x:3700,dy:110,w:150,color:'#f8b800'},{x:4500,dy:120,w:140,color:'#f83800'}
    ],
    moves: [
      {x:2850,dy:170,w:130,minX:2800,maxX:3050,vx:2.0,color:'#f8b800'},
      {x:3600,dy:60,w:140,minX:3500,maxX:3800,vx:2.4,color:'#f8b800'}
    ],
    pipes: [{x:250,h:70},{x:1000,h:90},{x:1700,h:80},{x:3300,h:90},{x:4800,h:70}],
    walkers: [{x:330,range:150},{x:1500,range:150},{x:3100,range:150},{x:4860,range:300}],
    coins: [{x:150,dy:90},{x:420,dy:120},{x:650,dy:160},{x:980,dy:140},{x:1380,dy:170},{x:1650,dy:120},{x:2080,dy:150},{x:2550,dy:120},{x:2920,dy:180},{x:3350,dy:110},{x:3750,dy:160},{x:4550,dy:170},{x:5000,dy:100}],
    goalX: 5350
  },
  {
    name: 'Летњи залазак', collectible: '🍉', enemy: 'mouse', goal: 'house', music: 'summer', pitHazard: 'water',
    walker: 'bee',
    bgSky: '#fc7438', groundColor: '#f8b800', hillColor: '#d88000', pipeColor: '#00a800',
    stairColor: '#c89100',
    isNight: false, decor: null, noClouds: false,
    stairs: [{x:2450,peak:3,w:56,h:40},{x:4300,peak:4,w:56,h:40}],
    grounds: [{x:0,w:600},{x:900,w:400},{x:1550,w:500},{x:2400,w:500},{x:3250,w:450},{x:4050,w:800},{x:5100,w:700}],
    floats: [
      {x:720,dy:120,w:150,color:'#00a800'},{x:1420,dy:110,w:140,color:'#f8b800'},
      {x:2180,dy:130,w:160,color:'#00a800'},{x:3030,dy:110,w:160,color:'#f83800'},
      {x:3850,dy:120,w:150,color:'#00a800'},{x:4960,dy:100,w:140,color:'#f8b800'}
    ],
    moves: [
      {x:2120,dy:60,w:150,minX:2050,maxX:2350,vx:2.4,color:'#00a800'},
      {x:3450,dy:170,w:130,minX:3400,maxX:3650,vx:2.0,color:'#f8b800'}
    ],
    pipes: [{x:350,h:80},{x:1000,h:90},{x:1800,h:80},{x:4200,h:80},{x:5300,h:70}],
    walkers: [{x:430,range:150},{x:1070,range:180},{x:1560,range:180},{x:3250,range:200}],
    coins: [{x:200,dy:90},{x:420,dy:130},{x:760,dy:170},{x:1000,dy:140},{x:1450,dy:160},{x:1800,dy:100},{x:2220,dy:180},{x:2600,dy:130},{x:3070,dy:160},{x:3500,dy:200},{x:4450,dy:140},{x:5300,dy:100}],
    goalX: 5450
  },
  {
    name: 'Јесења ноћ', collectible: '🍎', enemy: 'mouse', goal: 'house', music: 'autumn', pitHazard: 'spikes',
    walker: 'hedgehog',
    bgSky: '#00003c', groundColor: '#cc5500', hillColor: '#882200', pipeColor: '#387800',
    stairColor: '#994000',
    isNight: true, decor: 'leaves', noClouds: false,
    stairs: [{x:2900,peak:3,w:56,h:40},{x:5400,peak:4,w:56,h:40}],
    grounds: [{x:0,w:1100},{x:1400,w:900},{x:2700,w:1000},{x:4100,w:900},{x:5400,w:1400}],
    floats: [
      {x:420,dy:110,w:140,color:'#f8b800'},{x:620,dy:180,w:130,color:'#f83800'},{x:820,dy:250,w:120,color:'#f8b800'},
      {x:1200,dy:120,w:140,color:'#f8b800'},
      {x:1800,dy:120,w:140,color:'#f83800'},{x:1980,dy:190,w:130,color:'#f8b800'},
      {x:2450,dy:150,w:150,color:'#f83800'},
      {x:3200,dy:110,w:140,color:'#f8b800'},{x:3380,dy:180,w:130,color:'#f83800'},{x:3540,dy:250,w:120,color:'#f8b800'},
      {x:3850,dy:140,w:150,color:'#f83800'},
      {x:4400,dy:120,w:140,color:'#f8b800'},{x:4580,dy:190,w:130,color:'#f83800'},
      {x:5150,dy:130,w:150,color:'#f83800'},
      {x:5900,dy:110,w:140,color:'#f8b800'},{x:6080,dy:180,w:130,color:'#f83800'},{x:6260,dy:250,w:120,color:'#f8b800'}
    ],
    moves: [
      {x:2500,dy:70,w:150,minX:2420,maxX:2680,vx:2.2,color:'#f8b800'},
      {x:3900,dy:60,w:150,minX:3820,maxX:4060,vx:2.2,color:'#f8b800'},
      {x:5180,dy:170,w:130,minX:5100,maxX:5320,vx:2.0,color:'#f8b800'}
    ],
    pipes: [{x:200,h:70},{x:900,h:90},{x:1600,h:80},{x:4300,h:80},{x:5800,h:70}],
    walkers: [{x:300,range:420},{x:1700,range:400},{x:4400,range:400},{x:5900,range:400}],
    coins: [{x:150,dy:90},{x:460,dy:160},{x:660,dy:230},{x:860,dy:300},{x:1150,dy:170},{x:1840,dy:170},{x:2020,dy:240},{x:2450,dy:190},{x:3240,dy:160},{x:3420,dy:230},{x:3900,dy:110},{x:5950,dy:160}],
    goalX: 6500
  },
  {
    name: 'Зимски снег', collectible: '🥕', enemy: 'mouse', goal: 'house', music: 'winter', pitHazard: 'spikes',
    walker: 'snowman',
    bgSky: '#a0c0f8', groundColor: '#f8f8f8', hillColor: '#c0d8f8', pipeColor: '#3888c8',
    stairColor: '#d8e0f0',
    isNight: false, decor: 'snow', noClouds: false,
    stairs: [{x:2650,peak:3,w:56,h:40},{x:5300,peak:4,w:56,h:40}],
    grounds: [{x:0,w:1000},{x:1300,w:950},{x:2600,w:950},{x:3900,w:1000},{x:5200,w:1500}],
    floats: [
      {x:380,dy:120,w:140,color:'#3888c8'},{x:560,dy:190,w:130,color:'#f8b800'},{x:740,dy:260,w:120,color:'#3888c8'},
      {x:1120,dy:130,w:140,color:'#3888c8'},
      {x:1700,dy:110,w:140,color:'#f8b800'},{x:1880,dy:180,w:130,color:'#3888c8'},
      {x:2380,dy:140,w:150,color:'#f83800'},
      {x:3000,dy:120,w:140,color:'#3888c8'},{x:3180,dy:190,w:130,color:'#f8b800'},{x:3360,dy:250,w:120,color:'#3888c8'},
      {x:3680,dy:130,w:150,color:'#f83800'},
      {x:4200,dy:110,w:140,color:'#f8b800'},{x:4380,dy:180,w:130,color:'#3888c8'},{x:4560,dy:250,w:120,color:'#f8b800'},
      {x:5020,dy:120,w:150,color:'#f83800'},
      {x:5800,dy:110,w:140,color:'#f8b800'},{x:5980,dy:180,w:130,color:'#3888c8'},{x:6160,dy:250,w:120,color:'#f8b800'}
    ],
    moves: [
      {x:2450,dy:70,w:150,minX:2380,maxX:2600,vx:2.2,color:'#3888c8'},
      {x:3750,dy:60,w:150,minX:3680,maxX:3900,vx:2.2,color:'#3888c8'}
    ],
    pipes: [{x:200,h:80},{x:1300,h:90},{x:2000,h:80},{x:3900,h:90},{x:5900,h:80}],
    walkers: [{x:300,range:420},{x:1400,range:400},{x:3000,range:400},{x:6000,range:300}],
    coins: [{x:150,dy:90},{x:420,dy:170},{x:600,dy:240},{x:1150,dy:180},{x:1740,dy:160},{x:1920,dy:230},{x:2430,dy:190},{x:3040,dy:170},{x:3220,dy:240},{x:3730,dy:180},{x:5830,dy:160},{x:6130,dy:230}],
    goalX: 6450
  },
  {
    name: 'Подземље', collectible: '🍄', enemy: 'mole', goal: 'mine', music: 'underground', pitHazard: 'lava',
    walker: 'worm',
    bgSky: '#3a2a1a', groundColor: '#8a5a33', hillColor: '#6b4526', pipeColor: '#7a4f2a',
    stairColor: '#6b4526',
    isNight: false, decor: null, noClouds: true, ceiling: true, ceilingColor: '#5a3f28',
    stairs: [{x:1300,peak:3,w:44,h:40},{x:3900,peak:4,w:44,h:40}],
    grounds: [{x:0,w:400},{x:600,w:350},{x:1150,w:400},{x:1700,w:350},{x:2250,w:400},{x:2800,w:350},{x:3350,w:400},{x:3900,w:350},{x:4450,w:1100}],
    floats: [
      {x:480,dy:110,w:120,color:'#a07030'},{x:1030,dy:130,w:120,color:'#c88a30'},
      {x:1610,dy:90,w:130,color:'#a07030'},{x:2160,dy:110,w:120,color:'#c88a30'},
      {x:2710,dy:90,w:130,color:'#a07030'},{x:3260,dy:120,w:120,color:'#c88a30'},
      {x:3810,dy:100,w:130,color:'#a07030'},{x:4330,dy:110,w:130,color:'#c88a30'}
    ],
    moves: [
      {x:1800,dy:80,w:120,minX:1750,maxX:1950,vx:2.0,color:'#a07030'},
      {x:3000,dy:70,w:120,minX:2950,maxX:3150,vx:2.2,color:'#c88a30'}
    ],
    pipes: [{x:150,h:70},{x:700,h:90},{x:2400,h:80},{x:3450,h:90},{x:4600,h:80},{x:5000,h:70}],
    walkers: [{x:220,range:150},{x:760,range:160},{x:2460,range:180},{x:4680,range:250}],
    coins: [{x:180,dy:100},{x:500,dy:150},{x:750,dy:130},{x:1080,dy:170},{x:1500,dy:120},{x:2220,dy:160},{x:2450,dy:130},{x:2760,dy:140},{x:2950,dy:110},{x:3320,dy:170},{x:4100,dy:120},{x:4700,dy:100}],
    goalX: 5250
  },
  {
    name: 'Пећина', collectible: '🍇', enemy: 'bat', goal: 'cave', music: 'cave', pitHazard: 'lava',
    walker: 'spider',
    bgSky: '#2a2a3a', groundColor: '#5a4a3a', hillColor: '#453a2e', pipeColor: '#5c5246',
    stairColor: '#453a2e',
    isNight: true, decor: null, noClouds: true, ceiling: true, ceilingColor: '#3a3340',
    stairs: [{x:1200,peak:3,w:44,h:40},{x:3850,peak:4,w:44,h:40}],
    grounds: [{x:0,w:380},{x:550,w:350},{x:1100,w:400},{x:1650,w:350},{x:2200,w:400},{x:2750,w:350},{x:3300,w:400},{x:3850,w:350},{x:4400,w:1000}],
    floats: [
      {x:460,dy:100,w:130,color:'#7a6a55'},{x:990,dy:120,w:120,color:'#8a7a60'},
      {x:1560,dy:90,w:120,color:'#7a6a55'},{x:2110,dy:110,w:120,color:'#8a7a60'},
      {x:2660,dy:90,w:130,color:'#7a6a55'},{x:3210,dy:120,w:120,color:'#8a7a60'},
      {x:3760,dy:100,w:130,color:'#7a6a55'},{x:4280,dy:110,w:130,color:'#8a7a60'}
    ],
    moves: [
      {x:1750,dy:80,w:120,minX:1700,maxX:1900,vx:2.0,color:'#7a6a55'},
      {x:2950,dy:60,w:120,minX:2900,maxX:3100,vx:2.2,color:'#8a7a60'}
    ],
    pipes: [{x:150,h:70},{x:700,h:90},{x:2300,h:90},{x:4550,h:80}],
    walkers: [{x:220,range:140},{x:760,range:130},{x:2380,range:200},{x:4650,range:250}],
    coins: [{x:140,dy:100},{x:500,dy:150},{x:760,dy:130},{x:1040,dy:170},{x:1350,dy:120},{x:2250,dy:150},{x:2520,dy:130},{x:2710,dy:140},{x:3080,dy:110},{x:3260,dy:170},{x:3980,dy:120},{x:4700,dy:100}],
    goalX: 5150
  },
  {
    name: 'Подводни свет', collectible: '🐚', enemy: 'piranha', goal: 'submarine', music: 'water', pitHazard: 'spikes',
    walker: 'crab',
    bgSky: '#1a6a9a', groundColor: '#d9b98a', hillColor: '#1a5a8a', pipeColor: '#3a8ac0',
    stairColor: '#b09868',
    isNight: false, decor: 'bubbles', noClouds: true,
    stairs: [{x:2150,peak:3,w:56,h:40},{x:4500,peak:4,w:56,h:40}],
    grounds: [{x:0,w:500},{x:750,w:450},{x:1400,w:450},{x:2100,w:500},{x:2850,w:450},{x:3600,w:500},{x:4400,w:1100}],
    floats: [
      {x:600,dy:110,w:140,color:'#2a9a5a'},{x:1280,dy:130,w:140,color:'#7ac8e8'},
      {x:1950,dy:110,w:140,color:'#2a9a5a'},{x:2700,dy:130,w:140,color:'#7ac8e8'},
      {x:3420,dy:120,w:150,color:'#2a9a5a'},{x:4220,dy:110,w:150,color:'#7ac8e8'}
    ],
    moves: [
      {x:1550,dy:70,w:130,minX:1500,maxX:1750,vx:2.0,color:'#7ac8e8'},
      {x:3050,dy:80,w:130,minX:3000,maxX:3200,vx:2.2,color:'#7ac8e8'}
    ],
    pipes: [{x:200,h:70},{x:900,h:90},{x:2500,h:80},{x:3700,h:80}],
    walkers: [{x:260,range:200},{x:960,range:220},{x:1430,range:200},{x:2880,range:200}],
    coins: [{x:180,dy:90},{x:420,dy:130},{x:640,dy:160},{x:950,dy:140},{x:1300,dy:180},{x:2000,dy:160},{x:2450,dy:130},{x:2750,dy:180},{x:3150,dy:120},{x:3480,dy:170},{x:4250,dy:160},{x:4800,dy:100}],
    goalX: 5250
  },
  {
    name: 'Савана', collectible: '🍌', enemy: 'snake', goal: 'hut', music: 'savanna', pitHazard: 'spikes',
    walker: 'meerkat',
    bgSky: '#f8d870', groundColor: '#e0a860', hillColor: '#c89050', pipeColor: '#a87830',
    stairColor: '#bd8a44',
    isNight: false, decor: null, noClouds: false,
    stairs: [{x:2900,peak:3,w:56,h:40},{x:5700,peak:4,w:56,h:40}],
    grounds: [{x:0,w:1100},{x:1400,w:1100},{x:2800,w:1100},{x:4200,w:1100},{x:5600,w:1400}],
    floats: [
      {x:1200,dy:110,w:150,color:'#c89050'},{x:2620,dy:120,w:150,color:'#e8c878'},
      {x:4030,dy:110,w:150,color:'#c89050'},{x:5430,dy:120,w:150,color:'#e8c878'}
    ],
    moves: [
      {x:2000,dy:90,w:140,minX:1900,maxX:2150,vx:2.2,color:'#c89050'},
      {x:5000,dy:80,w:140,minX:4900,maxX:5150,vx:2.4,color:'#e8c878'}
    ],
    pipes: [{x:300,h:80},{x:1600,h:90},{x:3500,h:80},{x:4400,h:90},{x:6200,h:70}],
    walkers: [{x:390,range:380},{x:1700,range:450},{x:4500,range:350},{x:6300,range:300}],
    coins: [{x:150,dy:90},{x:500,dy:120},{x:900,dy:130},{x:1250,dy:160},{x:1700,dy:120},{x:2200,dy:110},{x:2650,dy:170},{x:3200,dy:120},{x:3800,dy:100},{x:4080,dy:160},{x:5000,dy:130},{x:6000,dy:100}],
    goalX: 6750
  },
  {
    name: 'Јапан', collectible: '🍙', enemy: 'oni', goal: 'torii', music: 'japan', pitHazard: 'water',
    walker: 'panda',
    bgSky: '#f8a0c0', groundColor: '#e0707f', hillColor: '#c85a6a', pipeColor: '#b05060',
    stairColor: '#b84f5e',
    isNight: false, decor: 'petals', noClouds: false,
    stairs: [{x:2600,peak:3,w:56,h:40},{x:5300,peak:4,w:56,h:40}],
    grounds: [{x:0,w:950},{x:1250,w:900},{x:2500,w:950},{x:3800,w:1000},{x:5100,w:1600}],
    floats: [
      {x:400,dy:110,w:140,color:'#d05870'},{x:580,dy:180,w:130,color:'#f0a0b0'},{x:760,dy:250,w:120,color:'#d05870'},
      {x:1070,dy:120,w:140,color:'#f0a0b0'},
      {x:1600,dy:120,w:140,color:'#d05870'},{x:1780,dy:190,w:130,color:'#f0a0b0'},
      {x:2280,dy:140,w:150,color:'#f0a0b0'},
      {x:2950,dy:110,w:140,color:'#f0a0b0'},{x:3130,dy:180,w:130,color:'#d05870'},{x:3310,dy:250,w:120,color:'#f0a0b0'},
      {x:3600,dy:130,w:150,color:'#d05870'},
      {x:4100,dy:110,w:140,color:'#d05870'},{x:4280,dy:180,w:130,color:'#f0a0b0'},
      {x:4930,dy:120,w:140,color:'#f0a0b0'},
      {x:5800,dy:110,w:140,color:'#d05870'},{x:5980,dy:180,w:130,color:'#f0a0b0'},{x:6160,dy:250,w:120,color:'#d05870'}
    ],
    moves: [
      {x:2350,dy:70,w:150,minX:2280,maxX:2500,vx:2.2,color:'#d05870'},
      {x:3650,dy:60,w:140,minX:3600,maxX:3800,vx:2.2,color:'#f0a0b0'}
    ],
    pipes: [{x:200,h:70},{x:900,h:90},{x:1600,h:80},{x:2500,h:90},{x:4400,h:80}],
    walkers: [{x:260,range:450},{x:1280,range:250},{x:2950,range:400},{x:5800,range:400}],
    coins: [{x:150,dy:90},{x:440,dy:160},{x:620,dy:230},{x:1100,dy:170},{x:1640,dy:170},{x:1820,dy:240},{x:2330,dy:190},{x:2990,dy:160},{x:3170,dy:230},{x:3650,dy:180},{x:5850,dy:160},{x:6030,dy:230}],
    goalX: 6400
  },
  {
    name: 'Северни пол', collectible: '🎁', enemy: 'penguin', goal: 'igloo', music: 'northpole', pitHazard: 'spikes',
    walker: 'seal',
    bgSky: '#b8d8f0', groundColor: '#f0f8fc', hillColor: '#c8e0f0', pipeColor: '#a0c0d8',
    stairColor: '#d0e4f0',
    isNight: false, decor: 'snow', noClouds: false,
    stairs: [{x:3000,peak:3,w:56,h:40},{x:5800,peak:4,w:56,h:40}],
    grounds: [{x:0,w:1200},{x:1500,w:1100},{x:2900,w:1100},{x:4300,w:1100},{x:5700,w:1400}],
    floats: [
      {x:1320,dy:110,w:150,color:'#a0d0f0'},{x:2730,dy:120,w:150,color:'#e8f8ff'},
      {x:4130,dy:110,w:150,color:'#a0d0f0'},{x:5530,dy:120,w:150,color:'#e8f8ff'}
    ],
    moves: [
      {x:2100,dy:90,w:140,minX:2000,maxX:2250,vx:2.2,color:'#a0d0f0'},
      {x:5100,dy:80,w:140,minX:5000,maxX:5250,vx:2.4,color:'#a0d0f0'}
    ],
    pipes: [{x:300,h:80},{x:1700,h:90},{x:3300,h:80},{x:4500,h:90},{x:6300,h:70}],
    walkers: [{x:390,range:410},{x:1800,range:450},{x:3400,range:400},{x:6400,range:300}],
    coins: [{x:150,dy:90},{x:500,dy:120},{x:900,dy:130},{x:1350,dy:160},{x:1750,dy:120},{x:2250,dy:110},{x:2780,dy:170},{x:3250,dy:120},{x:3900,dy:100},{x:4180,dy:160},{x:5100,dy:130},{x:6100,dy:100}],
    goalX: 6850
  },
  {
    name: 'Египат', collectible: '🌴', enemy: 'scorpion', goal: 'pyramid', music: 'egypt', pitHazard: 'spikes',
    walker: 'scarab',
    bgSky: '#f8d878', groundColor: '#e8c878', hillColor: '#d0a860', pipeColor: '#b89038',
    stairColor: '#c8a758',
    isNight: false, decor: null, noClouds: false,
    stairs: [{x:2950,peak:3,w:56,h:40},{x:5750,peak:4,w:56,h:40}],
    grounds: [{x:0,w:1150},{x:1450,w:1100},{x:2850,w:1100},{x:4250,w:1100},{x:5650,w:1400}],
    floats: [
      {x:1270,dy:110,w:150,color:'#d0a860'},{x:2680,dy:120,w:150,color:'#f0d898'},
      {x:4080,dy:110,w:150,color:'#d0a860'},{x:5480,dy:120,w:150,color:'#f0d898'}
    ],
    moves: [
      {x:2050,dy:90,w:140,minX:1950,maxX:2200,vx:2.2,color:'#d0a860'},
      {x:5050,dy:80,w:140,minX:4950,maxX:5200,vx:2.4,color:'#f0d898'}
    ],
    pipes: [{x:300,h:80},{x:1650,h:90},{x:3300,h:80},{x:4450,h:90},{x:6300,h:70}],
    walkers: [{x:390,range:410},{x:1750,range:450},{x:3400,range:400},{x:6400,range:300}],
    coins: [{x:150,dy:90},{x:500,dy:120},{x:900,dy:130},{x:1300,dy:160},{x:1700,dy:120},{x:2200,dy:110},{x:2730,dy:170},{x:3200,dy:120},{x:3800,dy:100},{x:4130,dy:160},{x:5050,dy:130},{x:6050,dy:100}],
    goalX: 6800
  }
];

function shuffleArr(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

let worldOrder = shuffleArr(WORLDS.map((_, i) => i));
let worldPos = 0;

// Ground-walkers (task 68): how far below the drawing origin each walker sprite's
// feet sit, so the sprite stands flush on the ground. All walkers are smaller
// than the kitty (48px tall).
const WALKER_FOOT = {
    ladybug: 10, bee: 10, hedgehog: 14, snowman: 18, worm: 10,
    spider: 8, crab: 10, meerkat: 15, panda: 14, seal: 13, scarab: 9
};

let player, platforms, movingPlatforms, pipes, coins, goal, particles, mice, walkers, theme, levelCompleted, stairSteps, groundY = 0;

// --- Little Explorer hero sprites (task 73) + character picker (task 90) ---
// Two selectable heroes, each with six native right-facing frames in its own
// folder under game/assets/images/; the left direction is a runtime mirror
// (ctx.scale(-1, squish) below). Every source PNG has the feet on a shared
// baseline above the canvas bottom (measured per character), so all frames
// share one draw offset. We pre-scale the full canvas minus the uniform bottom
// gap to a 60px tall frame (bigger than the 48px hitbox, per user 2026-08-06)
// — anchored feet-flush on the hitbox bottom, so only the head overhangs
// ~12px upward. No getImageData, so this works even under file://.
const EXPLORER_SPRITE_H = 60;
const CHARACTERS = {
    kitty: { // default (per user 2026-08-07)
        name: 'Маца Истраживачица',
        folder: 'explorer_kitty/',
        srcW: 273,
        srcH: 312 // 334 - 22 (uniform transparent bottom gap, measured 2026-08-07)
    },
    explorer: {
        name: 'Истраживачица',
        folder: 'explorer/',
        srcW: 237,
        srcH: 329 // 352 - 23 (uniform transparent bottom gap)
    }
};
let selectedCharacter = 'kitty';
const EXPLORER_FRAMES = {
    idle: ['01_idle_right.png', '04_idle_right_b.png', '06_idle_right_c.png'],
    walk: ['02_walk_right.png'],
    run: ['03_run_right.png'],
    jump: ['05_jump_right.png']
};
const explorerFrames = {};
window.__explorerFrames = explorerFrames;

function loadExplorerFrame(key, file) {
    const c = CHARACTERS[selectedCharacter];
    const img = new Image();
    img.onload = () => {
        const w = Math.max(1, Math.round(c.srcW * EXPLORER_SPRITE_H / c.srcH));
        const frame = document.createElement('canvas');
        frame.width = w;
        frame.height = EXPLORER_SPRITE_H;
        const f2d = frame.getContext('2d');
        f2d.drawImage(img, 0, 0, c.srcW, c.srcH, 0, 0, w, EXPLORER_SPRITE_H);
        if (key === 'idle') {
            explorerFrames.idle = explorerFrames.idle || [];
            explorerFrames.idle.push(frame);
        } else {
            explorerFrames[key] = frame;
        }
    };
    img.src = '../assets/images/' + c.folder + file;
}
function loadExplorerFrames() {
    ['idle', 'walk', 'run', 'jump'].forEach(k => delete explorerFrames[k]);
    Object.entries(EXPLORER_FRAMES).forEach(([key, files]) => files.forEach(f => loadExplorerFrame(key, f)));
}

function currentExplorerFrame() {
    const s = player && player.animState;
    if (s === 'jump') return explorerFrames.jump;
    if (s === 'run') {
        // Alternate run/walk strides (~167ms each) so running reads as a real
        // gait instead of a frozen run pose (task 73b, per user).
        return (Math.floor((player.animTime || 0) / 10) % 2 === 0) ? explorerFrames.run : explorerFrames.walk;
    }
    if (s === 'walk') return explorerFrames.walk;
    const list = explorerFrames.idle || [];
    if (!list.length) return undefined;
    return list[Math.floor((player.animTime || 0) / 22) % list.length];
}

function loadWorld() {
    const w = WORLDS[worldOrder[worldPos]];
    theme = w;
    // Best-effort init so music will start when permitted by the browser.
    try { initAudio(); } catch (e) { }
    startMusic(w.music);
    document.getElementById('level-num').innerText = worldPos + 1;
    document.getElementById('collect-emoji').innerText = w.collectible;
    document.getElementById('world-name').innerText = w.name;
    document.getElementById('win-modal').classList.remove('show');
    levelCompleted = false;

    player = {
        x: Math.max(280, Math.min(w.grounds[0].x + w.grounds[0].w - 70, canvas.width * 0.3)),
        y: 100,
        width: 48,
        height: 48,
        vx: 0,
        vy: 0,
        speed: 5.2,
        jumpPower: -13.5,
        grounded: false,
        facingRight: true,
        squish: 1,
        tailAngle: 0,
        animState: 'idle',
        animTime: 0,
        prevGrounded: false
    };

    const gY = canvas.height - 140;
    groundY = gY;

    platforms = w.grounds.map(g => ({ x: g.x, y: gY, width: g.w, height: 140, color: w.groundColor }))
        .concat(w.floats.map(f => ({ x: f.x, y: gY - f.dy, width: f.w, height: 26, color: f.color })));

    coins = w.coins.map(c => ({ x: c.x, y: gY - c.dy, collected: false }));

    // Stairs (ascending+descending stepped platforms) give every level verticality.
    // Steps are non-overlapping one-step blocks, so the player auto-climbs each riser.
    stairSteps = [];
    (w.stairs || []).forEach((st, si) => {
        const ascending = [];
        for (let i = 0; i < st.peak; i++) {
            ascending.push({ x: st.x + i * st.w, y: gY - (i + 1) * st.h, width: st.w, height: st.h, color: w.stairColor, isStair: true });
        }
        const descending = [];
        for (let j = 0; j < st.peak - 1; j++) {
            descending.push({ x: st.x + (st.peak + j) * st.w, y: gY - (st.peak - 1 - j) * st.h, width: st.w, height: st.h, color: w.stairColor, isStair: true });
        }
        stairSteps = stairSteps.concat(ascending, descending);

        // Stair coins: every other ascending step on the first staircase only.
        if (si === 0) {
            ascending.forEach((s, i) => {
                if (i % 2 === 0) coins.push({ x: s.x + s.width / 2, y: s.y - 28, collected: false });
            });
        }
    });
    platforms = platforms.concat(stairSteps);

    movingPlatforms = w.moves.map(m => ({
        x: m.x, y: gY - m.dy, width: m.w, height: 22,
        minX: m.minX, maxX: m.maxX, vx: m.vx, color: m.color
    }));

    pipes = w.pipes.map(p => ({ x: p.x, y: gY - p.h, width: 60, height: p.h }));

    goal = { x: w.goalX, y: gY - 220, width: 220, height: 220 };

    particles = [];
    const nextMousePop = performance.now() + 3000;
    mice = pipes.map(pipe => ({
        x: pipe.x + pipe.width / 2,
        pipeY: pipe.y,
        hiddenY: pipe.y + 26,
        visibleY: pipe.y - 24,
        y: pipe.y + 26,
        visible: false,
        nextPopAt: nextMousePop,
        animationStart: 0
    }));

    // Ground-walking enemies: patrol [x, x+range] on the ground, flip at the ends.
    walkers = (w.walkers || []).map(wk => ({
        x: wk.x,
        minX: wk.x,
        maxX: wk.x + wk.range,
        dir: 1,
        vx: 1.3,
        dead: false,
        phase: Math.random() * Math.PI * 2,
        y: groundY - WALKER_FOOT[w.walker]
    }));
    worldLoaded = true;
}

function nextLevel() {
    playSound('pop');
    if (worldPos < worldOrder.length - 1) {
        worldPos++;
        loadWorld();
    } else {
        worldOrder = shuffleArr(WORLDS.map((_, i) => i));
        worldPos = 0;
        coinCount = 0;
        document.getElementById('coin-count').innerText = coinCount;
        loadWorld();
    }
}

// --- Worlds picker ---
function buildWorldsMenu() {
    const grid = document.getElementById('worlds-grid');
    grid.innerHTML = '';
    worldOrder.forEach((wi, idx) => {
        const w = WORLDS[wi];
        const btn = document.createElement('button');
        btn.className = 'world-btn';
        btn.innerHTML = '<span class="w-emoji">' + w.collectible + '</span>' + w.name;
        btn.addEventListener('click', () => {
            playSound('pop');
            worldPos = idx;
            coinCount = 0;
            document.getElementById('coin-count').innerText = coinCount;
            closeWorldsMenu();
            loadWorld();
        });
        grid.appendChild(btn);
    });
}

function openWorldsMenu() {
    initAudio();
    buildWorldsMenu();
    document.getElementById('worlds-modal').classList.add('show');
    setPaused(true);
}

function closeWorldsMenu() {
    document.getElementById('worlds-modal').classList.remove('show');
    setPaused(false);
}

document.getElementById('worlds-btn').addEventListener('click', openWorldsMenu);
document.getElementById('worlds-close').addEventListener('click', closeWorldsMenu);
document.getElementById('music-btn').addEventListener('click', () => setMusicOn(!musicOn));
document.getElementById('music-btn').textContent = musicOn ? '🔊' : '🔇';
document.getElementById('music-btn').classList.toggle('off', !musicOn);

function spawnParticles(x, y, color) {
    const MAX_PARTICLES = 120;
    if (particles.length > MAX_PARTICLES) return;
    for (let i = 0; i < 10; i++) {
        particles.push({
            x: x, y: y,
            vx: (Math.random() - 0.5) * 6,
            vy: (Math.random() - 0.5) * 6,
            radius: Math.random() * 5 + 3,
            color: color,
            alpha: 1
        });
    }
}

function respawnKitty() {
    player.y = 50;
    player.x = Math.max(50, player.x - 220);
    player.vy = 0;
}

// --- Main Game Loop ---
let cameraX = 0;

function update() {
    const previousX = player.x;

    if (!levelCompleted) {
        if (keys.left) {
            player.vx = Math.max(-player.speed, player.vx - 0.55);
            player.facingRight = false;
        } else if (keys.right) {
            player.vx = Math.min(player.speed, player.vx + 0.55);
            player.facingRight = true;
        } else {
            player.vx *= 0.8;
        }

        if (keys.jump && player.grounded) {
            player.vy = player.jumpPower;
            player.grounded = false;
            player.squish = 1.35;
            playSound('jump');
        }
    } else {
        player.vx *= 0.8;
    }

    const previousY = player.y;
    player.vy += 0.55; // Gravity
    player.x += player.vx;
    player.y += player.vy;
    player.squish += (1 - player.squish) * 0.12;
    player.tailAngle = Math.sin(Date.now() * 0.01) * 0.3;

    // Moving Platform Update & Riding logic
    movingPlatforms.forEach(mp => {
        if (levelCompleted) return;
        mp.x += mp.vx;
        if (mp.x <= mp.minX || mp.x + mp.width >= mp.maxX) {
            mp.vx *= -1;
        }

        // Carry player on moving platform
        if (player.x + player.width > mp.x &&
            player.x < mp.x + mp.width &&
            player.vy >= 0 &&
            player.y + player.height >= mp.y &&
            previousY + player.height <= mp.y + 24) {

            player.grounded = true;
            player.vy = 0;
            player.y = mp.y - player.height;
            player.x += mp.vx; // Transfer movement
        }
    });

    // Static Platform & Pipe Collisions
    player.grounded = false;
    const allSolid = [...platforms, ...pipes];

    allSolid.forEach(p => {
        if (player.x + player.width > p.x &&
            player.x < p.x + p.width &&
            player.vy >= 0 &&
            player.y + player.height >= p.y &&
            previousY + player.height <= p.y + 24) {

            player.grounded = true;
            player.vy = 0;
            player.y = p.y - player.height;
        }
    });

    // Pipes are solid obstacles from the sides as well as platforms from above.
    pipes.forEach(pipe => {
        const overlapsVertically = player.y < pipe.y + pipe.height &&
            player.y + player.height > pipe.y + 8;
        if (!overlapsVertically) return;

        if (player.vx > 0 && previousX + player.width <= pipe.x && player.x + player.width > pipe.x) {
            player.x = pipe.x - player.width;
            player.vx = 0;
        } else if (player.vx < 0 && previousX >= pipe.x + pipe.width && player.x < pipe.x + pipe.width) {
            player.x = pipe.x + pipe.width;
            player.vx = 0;
        }
    });

    // Stair steps: auto-climb one-step risers, otherwise block like walls.
    stairSteps.forEach(step => {
        const rightEdge = player.x + player.width;
        const feetY = player.y + player.height;

        if (player.vy >= 0) {
            let faceX = -1;
            if (player.vx > 0 && previousX + player.width <= step.x && rightEdge > step.x) {
                faceX = step.x;
            } else if (player.vx < 0 && previousX >= step.x + step.width && player.x < step.x + step.width) {
                faceX = step.x + step.width;
            }
            if (faceX >= 0 && feetY >= step.y - 2 && feetY <= step.y + step.height + 4) {
                player.y = step.y - player.height;
                player.vy = 0;
                player.grounded = true;
                return;
            }
        }

        const overlapsVertically = player.y < step.y + step.height && player.y + player.height > step.y + 8;
        if (!overlapsVertically) return;
        if (player.vx > 0 && previousX + player.width <= step.x && rightEdge > step.x) {
            player.x = step.x - player.width;
            player.vx = 0;
        } else if (player.vx < 0 && previousX >= step.x + step.width && player.x < step.x + step.width) {
            player.x = step.x + step.width;
            player.vx = 0;
        }
    });

    // Forgiving Toddler Teleport
    if (!levelCompleted && player.y > canvas.height + 100) respawnKitty();

    // Enemies briefly pop out of each pipe on a three-second cycle.
    const now = performance.now();
    mice.forEach(mouse => {
        if (mouse.visible) {
            const elapsed = now - mouse.animationStart;
            const riseDuration = 350;
            const holdDuration = 900;
            const slideDuration = 350;

            if (elapsed < riseDuration) {
                mouse.y = mouse.hiddenY + (mouse.visibleY - mouse.hiddenY) * (elapsed / riseDuration);
            } else if (elapsed < riseDuration + holdDuration) {
                mouse.y = mouse.visibleY;
            } else if (elapsed < riseDuration + holdDuration + slideDuration) {
                const progress = (elapsed - riseDuration - holdDuration) / slideDuration;
                mouse.y = mouse.visibleY + (mouse.hiddenY - mouse.visibleY) * progress;
            } else {
                mouse.visible = false;
                mouse.y = mouse.hiddenY;
            }
        } else if (now >= mouse.nextPopAt) {
            mouse.visible = true;
            mouse.animationStart = now;
            mouse.y = mouse.hiddenY;
            mouse.nextPopAt += 3000;
        }
    });

    const hitMouse = mice.find(mouse => mouse.visible && mouse.y <= mouse.visibleY + 8 &&
        player.x + player.width > mouse.x - 18 &&
        player.x < mouse.x + 18 &&
        player.y + player.height > mouse.y - 22 &&
        player.y < mouse.y + 22);
    if (hitMouse) {
        playHurtSound();
        hitMouse.visible = false;
        hitMouse.nextPopAt = now + 3000;
        respawnKitty();
    }

    // Ground-walking enemies: patrol left/right on the ground, gently bobbing.
    if (!levelCompleted) {
        walkers.forEach(w => {
            w.x += w.vx * w.dir;
            if (w.x <= w.minX) { w.x = w.minX; w.dir = 1; }
            else if (w.x >= w.maxX) { w.x = w.maxX; w.dir = -1; }
            w.phase += 0.14;
        });
    }

    // Walkers: land on top → defeated + a coin; touch their side → kitty respawns.
    const hitWalker = walkers.find(w => !w.dead &&
        player.x + player.width > w.x - 22 &&
        player.x < w.x + 22 &&
        player.y + player.height > groundY - 44 &&
        player.y < groundY);
    if (hitWalker) {
        if (player.vy >= 0 && player.y + player.height <= groundY - 6) {
            hitWalker.dead = true;
            coinCount++;
            document.getElementById('coin-count').innerText = coinCount;
            playSound('coin');
            spawnParticles(hitWalker.x, groundY - 24, '#FFD23F');
        } else {
            playHurtSound();
            respawnKitty();
        }
    }

    // Camera follow
    cameraX += (player.x - canvas.width / 3 - cameraX) * 0.1;
    cameraX = Math.max(0, cameraX);

    // Collectible Collection
    coins.forEach(c => {
        if (!levelCompleted && !c.collected &&
            player.x + player.width > c.x - 18 &&
            player.x < c.x + 18 &&
            player.y + player.height > c.y - 18 &&
            player.y < c.y + 18) {

            c.collected = true;
            coinCount++;
            document.getElementById('coin-count').innerText = coinCount;
            playSound('coin');
            spawnParticles(c.x, c.y, '#FFD23F');
        }
    });

    // Level Clear Goal
    if (!levelCompleted && player.x + player.width > goal.x + 30 && player.x < goal.x + goal.width) {
        levelCompleted = true;
        player.vx = 0;
        playSound('win');
        const modal = document.getElementById('win-modal');
        const title = document.getElementById('win-title');
        const btn = document.getElementById('modal-btn');

        if (worldPos < worldOrder.length - 1) {
            title.innerText = theme.name + "\nПРЕЂЕН!";
            btn.innerText = "СЛЕДЕЋИ СВЕТ! 🚀";
        } else {
            title.innerText = "🌟 СВИ СВЕТОВИ ПРЕЂЕНИ! 🌟";
            btn.innerText = "ИГРАЈ ПОНОВО! 🔄";
        }
        modal.classList.add('show');
    }

    // Particles
    for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.035;
        if (p.alpha <= 0) particles.splice(i, 1);
    }

    // --- Hero animation state (task 73) ---
    player.animTime += 1;
    if (!player.prevGrounded && player.grounded) player.squish = 0.8;
    player.prevGrounded = player.grounded;
    if (!player.grounded) {
        player.animState = 'jump';
    } else {
        const a = Math.abs(player.vx);
        if (a < 1.2) player.animState = 'idle';
        else if (a < 2.6) player.animState = 'walk';
        else player.animState = 'run';
    }
}

function drawPaperStitchLine(x1, y1, x2, y2) {
    ctx.save();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.setLineDash([8, 8]);
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
}

// Twinkling star sparkles around a collectible.
function drawSparkle(x, y) {
    const t = Date.now() / 1000;
    for (let i = 0; i < 3; i++) {
        const a = (Math.sin(t * 2.5 + i * 2.1) + 1) / 2;
        if (a < 0.2) continue;
        const angle = i * 2.1 + t * 0.6;
        const dist = 26 + (i % 2) * 9;
        const sx = x + Math.cos(angle) * dist;
        const sy = y + Math.sin(angle) * dist - 4;
        ctx.save();
        ctx.globalAlpha = a * 0.85;
        ctx.strokeStyle = '#FFD23F';
        ctx.lineWidth = 2;
        const s = 3 + a * 3.5;
        ctx.beginPath();
        ctx.moveTo(sx, sy - s);
        ctx.lineTo(sx, sy + s);
        ctx.moveTo(sx - s, sy);
        ctx.lineTo(sx + s, sy);
        ctx.stroke();
        ctx.restore();
    }
}

// --- Theme decor (snow, leaves, petals, bubbles) ---
function drawDecor(t) {
    if (theme.decor === 'snow') {
        ctx.fillStyle = '#ffffff';
        for (let i = 0; i < 22; i++) {
            const x = ((i * 173 + t * 40) % (canvas.width + 40)) - 20 + Math.sin(t * 2 + i) * 8;
            const y = ((i * 97 + t * 55) % (canvas.height + 40)) - 20;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();
        }
    } else if (theme.decor === 'leaves') {
        for (let i = 0; i < 20; i++) {
            const x = ((i * 191 + t * 45) % (canvas.width + 40)) - 20 + Math.sin(t * 1.5 + i * 2) * 12;
            const y = ((i * 113 + t * 60) % (canvas.height + 40)) - 20;
            ctx.fillStyle = i % 3 === 0 ? '#cc5500' : '#d88000';
            ctx.beginPath();
            ctx.ellipse(x, y, 5, 3, Math.sin(t + i) * 0.8, 0, Math.PI * 2);
            ctx.fill();
        }
    } else if (theme.decor === 'petals') {
        for (let i = 0; i < 20; i++) {
            const x = ((i * 149 + t * 35) % (canvas.width + 40)) - 20 + Math.sin(t * 1.8 + i * 3) * 15;
            const y = ((i * 127 + t * 50) % (canvas.height + 40)) - 20;
            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#ffd6e5';
            ctx.beginPath();
            ctx.arc(x, y, 2.5, 0, Math.PI * 2);
            ctx.fill();
        }
    } else if (theme.decor === 'bubbles') {
        for (let i = 0; i < 16; i++) {
            const x = ((i * 229 + t * 20) % (canvas.width + 40)) - 20;
            const y = canvas.height - ((i * 137 + t * 40) % (canvas.height + 40)) + 20;
            ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
            ctx.beginPath();
            ctx.arc(x, y, 5 + (i % 3) * 3, 0, Math.PI * 2);
            ctx.fill();
        }
    }
}

function drawPitHazards() {
    const hazard = theme.pitHazard;
    if (!hazard) return;
    const t = Date.now() / 1000;
    const gy = groundY;
    const depth = canvas.height - gy;
    const grounds = theme.grounds.slice().sort((a, b) => a.x - b.x);
    for (let i = 0; i < grounds.length - 1; i++) {
        const gx = grounds[i].x + grounds[i].w;
        const gapEnd = grounds[i + 1].x;
        if (gapEnd - gx < 8) continue;
        if (hazard === 'lava') {
            const grad = ctx.createLinearGradient(0, gy, 0, canvas.height);
            grad.addColorStop(0, '#ff5f2e');
            grad.addColorStop(0.5, '#ff7f1f');
            grad.addColorStop(1, '#b33a00');
            ctx.fillStyle = grad;
            ctx.fillRect(gx, gy, gapEnd - gx, depth);
            ctx.fillStyle = '#ffd166';
            ctx.fillRect(gx, gy, gapEnd - gx, 5);
            ctx.fillStyle = '#fff3c4';
            for (let k = 0; k < 6; k++) {
                const bx = gx + ((k * 41 + t * 26) % (gapEnd - gx));
                const by = canvas.height - 12 - ((k * 29 + t * 70) % (depth * 0.7));
                ctx.beginPath();
                ctx.arc(bx, by, 3.5, 0, Math.PI * 2);
                ctx.fill();
            }
        } else if (hazard === 'water') {
            const grad = ctx.createLinearGradient(0, gy, 0, canvas.height);
            grad.addColorStop(0, 'rgba(90,190,255,0.9)');
            grad.addColorStop(1, 'rgba(15,80,160,0.95)');
            ctx.fillStyle = grad;
            ctx.fillRect(gx, gy, gapEnd - gx, depth);
            ctx.fillStyle = 'rgba(255,255,255,0.5)';
            for (let k = 0; k < 3; k++) {
                const ry = gy + 8 + k * 14;
                const off = Math.sin(t * 2 + k) * 4;
                ctx.fillRect(gx + 4 + off, ry, gapEnd - gx - 8, 2);
            }
            ctx.fillStyle = '#ffffff';
            ctx.font = '22px "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            for (let k = 0; k < 2; k++) {
                const fx = gx + 18 + ((k * 37 + t * 22) % Math.max(1, gapEnd - gx - 36));
                const fy = canvas.height - 26 - ((k * 19 + Math.sin(t * 1.6 + k * 2.4) * 6) % (depth * 0.55));
                ctx.fillText('🐟', fx, fy);
            }
        } else if (hazard === 'spikes') {
            ctx.fillStyle = 'rgba(18,20,30,0.92)';
            ctx.fillRect(gx, gy, gapEnd - gx, depth);
            ctx.fillStyle = '#c7d2e0';
            for (let sx = gx + 12; sx < gapEnd - 6; sx += 24) {
                const h = 30 + Math.sin(sx * 0.33 + gx) * 8;
                ctx.beginPath();
                ctx.moveTo(sx - 10, canvas.height);
                ctx.lineTo(sx, canvas.height - h);
                ctx.lineTo(sx + 10, canvas.height);
                ctx.closePath();
                ctx.fill();
            }
            ctx.fillStyle = '#5c6a7a';
            ctx.fillRect(gx, canvas.height - 6, gapEnd - gx, 6);
        }
    }
}

function draw() {
    // Sky Background
    ctx.fillStyle = theme.bgSky;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const t = Date.now() / 1000;

    ctx.save();
    ctx.translate(-cameraX, 0);

    // Night Sky Stars
    if (theme.isNight) {
        ctx.fillStyle = "#ffffff";
        for (let sx = 100; sx < 7000; sx += 400) {
            ctx.fillRect(sx, 40, 4, 4);
            ctx.fillRect(sx + 120, 90, 4, 4);
        }
    }

    // Distant Hills
    ctx.fillStyle = theme.hillColor;
    for (let hx = 300; hx < 7200; hx += 800) {
        ctx.beginPath();
        ctx.arc(hx, canvas.height, 280, Math.PI, 0);
        ctx.fill();
    }

    // Clouds
    if (!theme.noClouds) {
        ctx.fillStyle = theme.isNight ? "rgba(255, 255, 255, 0.3)" : "#ffffff";
        for (let cx = 200; cx < 7200; cx += 550) {
            ctx.beginPath();
            ctx.arc(cx, 80, 45, 0, Math.PI * 2);
            ctx.arc(cx + 40, 70, 55, 0, Math.PI * 2);
            ctx.arc(cx + 80, 80, 45, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    drawPitHazards();

    // Draw Static Platforms
    platforms.forEach(p => {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(p.x - 4, p.y - 4, p.width + 8, p.height + 8);

        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, p.width, p.height);

        drawPaperStitchLine(p.x + 10, p.y + p.height / 2, p.x + p.width - 10, p.y + p.height / 2);
    });

    // Draw Moving Platforms
    movingPlatforms.forEach(mp => {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(mp.x - 4, mp.y - 4, mp.width + 8, mp.height + 8);

        ctx.fillStyle = mp.color;
        ctx.fillRect(mp.x, mp.y, mp.width, mp.height);

        drawPaperStitchLine(mp.x + 10, mp.y + mp.height / 2, mp.x + mp.width - 10, mp.y + mp.height / 2);
    });

    // Draw themed "spawner" pipes
    pipes.forEach(pipe => {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(pipe.x - 4, pipe.y - 4, pipe.width + 8, pipe.height + 8);

        ctx.fillStyle = theme.pipeColor;
        ctx.fillRect(pipe.x, pipe.y, pipe.width, pipe.height);

        ctx.fillRect(pipe.x - 6, pipe.y, pipe.width + 12, 24);

        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.fillRect(pipe.x + 6, pipe.y + 24, 8, pipe.height - 24);
        ctx.fillRect(pipe.x, pipe.y, 8, 24);
    });

    // Draw enemies only while they are above the pipe.
    mice.forEach(mouse => {
        if (!mouse.visible) return;
        ctx.save();
        ctx.beginPath();
        ctx.rect(mouse.x - 32, 0, 64, mouse.pipeY);
        ctx.clip();
        ctx.translate(mouse.x, mouse.y);
        drawEnemy(theme.enemy);
        ctx.restore();
    });

    // Draw ground-walking enemies (patrol left/right, theme-matched, gentle bob).
    walkers.forEach(w => {
        if (w.dead) return;
        ctx.save();
        ctx.translate(w.x, w.y + Math.sin(w.phase) * 1.5);
        ctx.scale(w.dir, 1);
        drawWalker(theme.walker);
        ctx.restore();
    });

    // Draw Collectibles (per-world emoji, no backing circle, bobbing + sparkling)
    coins.forEach(c => {
        if (!c.collected) {
            const bob = Math.sin(t * 2.2 + c.x * 0.05) * 5;
            const cy = c.y + bob;
            ctx.save();
            ctx.globalAlpha = 1;
            ctx.font = '36px "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(theme.collectible, c.x, cy + 1);
            drawSparkle(c.x, cy);
            ctx.restore();
        }
    });

    // Draw Themed Goal Building
    drawGoal(theme.goal, goal);

    // --- LITTLE EXPLORER HERO (sprite state machine) ---
    const heroFrame = currentExplorerFrame();
    if (heroFrame) {
        ctx.save();
        ctx.translate(player.x + player.width / 2, player.y + player.height / 2);
        ctx.scale(player.facingRight ? 1 : -1, player.squish);
        // Feet flush on the hitbox bottom; the sprite is taller than the hitbox,
        // so its head overhangs upward (no grounded bob per user 2026-08-06).
        ctx.drawImage(heroFrame, -heroFrame.width / 2, player.height / 2 - EXPLORER_SPRITE_H, heroFrame.width, heroFrame.height);
        ctx.restore();
    }

    // Particles
    particles.forEach(p => {
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    });

    ctx.restore();

    if (theme.ceiling) drawCeiling();

    drawDecor(t);
}

// --- Rock ceiling for underground/cave worlds (screen-fixed) ---
function drawCeiling() {
    ctx.fillStyle = theme.ceilingColor;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(canvas.width, 0);
    for (let x = canvas.width; x >= 0; x -= 90) {
        const y = 62 + Math.sin(x * 0.05) * 16 + ((x / 90) % 2) * 12;
        ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();

    for (let sx = 40; sx < canvas.width; sx += 170) {
        ctx.beginPath();
        ctx.moveTo(sx - 16, 72);
        ctx.lineTo(sx, 72 + 26 + (sx % 3) * 14);
        ctx.lineTo(sx + 16, 72);
        ctx.closePath();
        ctx.fill();
    }
}

// --- Enemy drawings (same pop-out mechanic, themed look) ---
function drawEnemy(type) {
    if (type === 'mouse') {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 5, 17, 0, Math.PI * 2);
        ctx.arc(-11, -10, 9, 0, Math.PI * 2);
        ctx.arc(11, -10, 9, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#8f6ad8';
        ctx.beginPath();
        ctx.arc(0, 5, 14, 0, Math.PI * 2);
        ctx.arc(-11, -10, 6, 0, Math.PI * 2);
        ctx.arc(11, -10, 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#f4a6c1';
        ctx.beginPath();
        ctx.arc(-11, -10, 3, 0, Math.PI * 2);
        ctx.arc(11, -10, 3, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-5, 2, 2, 0, Math.PI * 2);
        ctx.arc(5, 2, 2, 0, Math.PI * 2);
        ctx.arc(0, 8, 2, 0, Math.PI * 2);
        ctx.fill();
    } else if (type === 'mole') {
        ctx.fillStyle = '#5a4632';
        ctx.beginPath();
        ctx.arc(0, 5, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f4a6c1';
        ctx.beginPath();
        ctx.arc(0, 9, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-6, 0, 2.5, 0, Math.PI * 2);
        ctx.arc(6, 0, 2.5, 0, Math.PI * 2);
        ctx.fill();
    } else if (type === 'bat') {
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.moveTo(-20, -14);
        ctx.lineTo(0, -4);
        ctx.lineTo(20, -14);
        ctx.lineTo(14, 6);
        ctx.lineTo(0, 8);
        ctx.lineTo(-14, 6);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#4a3f6b';
        ctx.beginPath();
        ctx.arc(0, 0, 9, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff4d6d';
        ctx.beginPath();
        ctx.arc(-3, -1, 1.5, 0, Math.PI * 2);
        ctx.arc(3, -1, 1.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#f4a6c1';
        ctx.beginPath();
        ctx.moveTo(-6, -6);
        ctx.lineTo(-4, -12);
        ctx.lineTo(-2, -6);
        ctx.moveTo(6, -6);
        ctx.lineTo(4, -12);
        ctx.lineTo(2, -6);
        ctx.fill();
    } else if (type === 'piranha') {
        ctx.fillStyle = '#ff6f3c';
        ctx.beginPath();
        ctx.ellipse(0, 3, 18, 12, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffd6c8';
        ctx.beginPath();
        ctx.ellipse(-3, 8, 12, 6, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff6f3c';
        ctx.beginPath();
        ctx.moveTo(16, 3);
        ctx.lineTo(26, -4);
        ctx.lineTo(24, 8);
        ctx.lineTo(16, 10);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(4, 0);
        ctx.lineTo(14, -2);
        ctx.lineTo(14, 2);
        ctx.lineTo(11, 1);
        ctx.lineTo(10, 4);
        ctx.lineTo(7, 2);
        ctx.lineTo(4, 4);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-8, 0, 3, 0, Math.PI * 2);
        ctx.fill();
    } else if (type === 'snake') {
        ctx.fillStyle = '#67c971';
        ctx.beginPath();
        ctx.arc(0, 12, 10, 0, Math.PI * 2);
        ctx.arc(0, -2, 9, 0, Math.PI * 2);
        ctx.arc(0, -14, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-3, -16, 2, 0, Math.PI * 2);
        ctx.arc(3, -16, 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ff4d6d';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, -21);
        ctx.lineTo(3, -27);
        ctx.lineTo(6, -23);
        ctx.moveTo(0, -21);
        ctx.lineTo(-3, -27);
        ctx.lineTo(-6, -23);
        ctx.stroke();
    } else if (type === 'oni') {
        ctx.fillStyle = '#e52521';
        ctx.beginPath();
        ctx.arc(0, 2, 15, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fbd000';
        ctx.beginPath();
        ctx.moveTo(-11, -6);
        ctx.lineTo(-7, -20);
        ctx.lineTo(-4, -8);
        ctx.moveTo(11, -6);
        ctx.lineTo(7, -20);
        ctx.lineTo(4, -8);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-5, -1, 4, 0, Math.PI * 2);
        ctx.arc(5, -1, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-5, -1, 2, 0, Math.PI * 2);
        ctx.arc(5, -1, 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(-4, 8);
        ctx.lineTo(4, 8);
        ctx.lineTo(2, 13);
        ctx.lineTo(-2, 13);
        ctx.closePath();
        ctx.fill();
    } else if (type === 'penguin') {
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.ellipse(0, 3, 13, 17, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.ellipse(0, 7, 8, 11, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ff8c42';
        ctx.beginPath();
        ctx.moveTo(-4, -6);
        ctx.lineTo(4, -6);
        ctx.lineTo(0, 1);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-4, -12, 2.5, 0, Math.PI * 2);
        ctx.arc(4, -12, 2.5, 0, Math.PI * 2);
        ctx.fill();
    } else if (type === 'scorpion') {
        ctx.fillStyle = '#8b5e3c';
        ctx.beginPath();
        ctx.ellipse(0, 6, 14, 9, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#5a3a26';
        ctx.beginPath();
        ctx.moveTo(8, 1);
        ctx.quadraticCurveTo(20, -8, 26, -4);
        ctx.lineTo(20, 2);
        ctx.quadraticCurveTo(15, -1, 10, 4);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#8b5e3c';
        ctx.beginPath();
        ctx.arc(-10, 6, 5, 0, Math.PI * 2);
        ctx.arc(10, 6, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#5a3a26';
        ctx.beginPath();
        ctx.moveTo(-14, 2);
        ctx.lineTo(-20, -2);
        ctx.lineTo(-12, 6);
        ctx.moveTo(14, 2);
        ctx.lineTo(20, -2);
        ctx.lineTo(12, 6);
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(-4, 3, 1.8, 0, Math.PI * 2);
        ctx.arc(4, 3, 1.8, 0, Math.PI * 2);
        ctx.fill();
    }
}

// --- Ground-walking enemies (task 68): patrol enemies drawn per world theme,
// separate from the pipe pop-out art. All are smaller than the kitty (48px).
// Drawn facing right; the caller flips with ctx.scale(dir, 1).
function drawWalker(type) {
    if (type === 'ladybug') {
        ctx.fillStyle = '#e52521';
        ctx.beginPath();
        ctx.ellipse(0, -2, 13, 11, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.arc(11, -2, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(-6, -5, 2.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(-1, -7, 2.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(-6, 2, 2.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(3, 3, 2.6, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.45)';
        ctx.beginPath(); ctx.arc(-9, -6, 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(13, -4, 2.2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#2b2d42';
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        for (let i = -1; i <= 1; i++) {
            ctx.moveTo(i * 5 - 3, 6);
            ctx.lineTo(i * 5 - 4, 10);
            ctx.moveTo(i * 5 + 3, 6);
            ctx.lineTo(i * 5 + 4, 10);
        }
        ctx.stroke();
    } else if (type === 'bee') {
        ctx.fillStyle = 'rgba(255,255,255,0.75)';
        ctx.beginPath(); ctx.ellipse(-5, -9, 6, 10, -0.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(-13, -6, 5, 8, 0.4, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.moveTo(-12, 0); ctx.lineTo(-16, 1); ctx.lineTo(-12, 3); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#FFD23F';
        ctx.beginPath(); ctx.ellipse(0, 0, 12, 10, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.fillRect(-8, -6, 3, 12);
        ctx.fillRect(-2, -8, 3, 16);
        ctx.fillRect(4, -6, 3, 12);
        ctx.beginPath(); ctx.arc(11, 0, 7, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(13, -2, 2.2, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#2b2d42';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(9, -5); ctx.quadraticCurveTo(10, -12, 14, -13);
        ctx.moveTo(13, -5); ctx.quadraticCurveTo(15, -11, 19, -11);
        ctx.stroke();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(14, -13, 1.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(19, -11, 1.6, 0, Math.PI * 2); ctx.fill();
    } else if (type === 'hedgehog') {
        ctx.fillStyle = '#8a5a33';
        for (let i = -2; i <= 2; i++) {
            ctx.beginPath();
            ctx.moveTo(i * 6 - 4, -8);
            ctx.lineTo(i * 6, -15);
            ctx.lineTo(i * 6 + 4, -8);
            ctx.closePath();
            ctx.fill();
        }
        ctx.fillStyle = '#b07850';
        ctx.beginPath(); ctx.ellipse(0, 3, 15, 10, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#e8c0a0';
        ctx.beginPath(); ctx.ellipse(11, 5, 6, 5, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(16, 4, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(5, -1, 2.2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#8a5a33';
        ctx.beginPath(); ctx.roundRect(-8, 12, 6, 4, 2); ctx.fill();
        ctx.beginPath(); ctx.roundRect(2, 12, 6, 4, 2); ctx.fill();
    } else if (type === 'snowman') {
        ctx.strokeStyle = '#8a5a33';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-11, -4); ctx.lineTo(-17, -1);
        ctx.moveTo(11, -4); ctx.lineTo(17, -1);
        ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(0, 6, 12, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(0, -9, 9, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = 'rgba(43,45,66,0.25)';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(0, 6, 12, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(-3, -11, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(3, -11, 2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ff8c42';
        ctx.beginPath(); ctx.moveTo(3, -8); ctx.lineTo(13, -7); ctx.lineTo(3, -6); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#e52521';
        ctx.fillRect(-9, -2, 18, 4);
        ctx.fillRect(-1, 2, 5, 8);
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(0, 2, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(0, 7, 1.5, 0, Math.PI * 2); ctx.fill();
    } else if (type === 'worm') {
        ctx.fillStyle = '#8a5a33';
        [[-14, 5, 4], [-7, 3, 5], [0, 0, 7], [7, 3, 5], [14, 5, 4]].forEach(s => {
            ctx.beginPath(); ctx.arc(s[0], s[1], s[2], 0, Math.PI * 2); ctx.fill();
        });
        ctx.beginPath(); ctx.arc(18, 4, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(19, 2, 1.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(22, 3, 1.4, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#8a5a33';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(16, -1); ctx.quadraticCurveTo(15, -7, 19, -8);
        ctx.moveTo(20, -1); ctx.quadraticCurveTo(22, -7, 25, -6);
        ctx.stroke();
        ctx.strokeStyle = '#5a3a26';
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(-12, 7); ctx.lineTo(-12, 10);
        ctx.moveTo(-5, 6); ctx.lineTo(-5, 9);
        ctx.moveTo(2, 5); ctx.lineTo(2, 8);
        ctx.moveTo(9, 6); ctx.lineTo(9, 9);
        ctx.stroke();
    } else if (type === 'spider') {
        ctx.strokeStyle = '#2b2d42';
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = -2; i <= 2; i++) {
            const sx = i * 5 - 1;
            ctx.moveTo(sx - 4, -4);
            ctx.quadraticCurveTo(sx - 8, 1, sx - 10, 8);
            ctx.moveTo(sx + 4, -4);
            ctx.quadraticCurveTo(sx + 8, 1, sx + 10, 8);
        }
        ctx.stroke();
        ctx.fillStyle = '#3a3340';
        ctx.beginPath(); ctx.arc(-3, -3, 9, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(7, 0, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ff4d6d';
        ctx.beginPath(); ctx.arc(-3, -3, 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(8, -2, 1.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(10, -1, 1.4, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(8, 2, 1.4, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(10, 3, 1.2, 0, Math.PI * 2); ctx.fill();
    } else if (type === 'crab') {
        ctx.strokeStyle = '#d34a20';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-8, 2); ctx.lineTo(-13, 7);
        ctx.moveTo(-3, 3); ctx.lineTo(-8, 9);
        ctx.moveTo(3, 3); ctx.lineTo(8, 9);
        ctx.moveTo(8, 2); ctx.lineTo(13, 7);
        ctx.stroke();
        ctx.fillStyle = '#ff6f3c';
        ctx.beginPath(); ctx.ellipse(0, 2, 11, 8, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#e85a2c';
        ctx.beginPath(); ctx.arc(10, -5, 4, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(15, -8, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(-10, -5, 4, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(-15, -8, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#e85a2c';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-3, -6); ctx.lineTo(-4, -11);
        ctx.moveTo(3, -6); ctx.lineTo(4, -11);
        ctx.stroke();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(-4, -12, 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(4, -12, 1.8, 0, Math.PI * 2); ctx.fill();
    } else if (type === 'meerkat') {
        ctx.fillStyle = '#d8a868';
        ctx.beginPath(); ctx.ellipse(0, 3, 9, 11, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#e8c898';
        ctx.beginPath(); ctx.ellipse(0, 5, 5, 7, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#8a5a33';
        ctx.beginPath(); ctx.roundRect(-11, -1, 4, 8, 2); ctx.fill();
        ctx.beginPath(); ctx.roundRect(7, -1, 4, 8, 2); ctx.fill();
        ctx.fillStyle = '#d8a868';
        ctx.beginPath(); ctx.arc(0, -9, 8, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#8a5a33';
        ctx.beginPath(); ctx.ellipse(-3, -10, 3.5, 4, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(3, -10, 3.5, 4, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(-3, -10, 1.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(3, -10, 1.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(0, -6, 1.6, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#d8a868';
        ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.moveTo(-7, 2); ctx.quadraticCurveTo(-14, -2, -12, -10); ctx.stroke();
        ctx.fillStyle = '#8a5a33';
        ctx.beginPath(); ctx.arc(-12, -11, 2, 0, Math.PI * 2); ctx.fill();
    } else if (type === 'panda') {
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.roundRect(-12, -2, 4, 9, 2); ctx.fill();
        ctx.beginPath(); ctx.roundRect(8, -2, 4, 9, 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.ellipse(0, 3, 11, 10, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.roundRect(-8, 9, 5, 5, 2); ctx.fill();
        ctx.beginPath(); ctx.roundRect(3, 9, 5, 5, 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(0, -9, 8, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(-6, -15, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(6, -15, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(-3, -10, 3, 3.5, -0.2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(3, -10, 3, 3.5, 0.2, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(-3, -10, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(3, -10, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(0, -6, 1.5, 0, Math.PI * 2); ctx.fill();
    } else if (type === 'seal') {
        ctx.fillStyle = '#c8d8e0';
        ctx.beginPath(); ctx.ellipse(0, 4, 14, 9, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#e8f0f4';
        ctx.beginPath(); ctx.ellipse(0, 7, 9, 5, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#a8b8c8';
        ctx.beginPath(); ctx.moveTo(-13, 1); ctx.lineTo(-19, 6); ctx.lineTo(-12, 8); ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.moveTo(-2, 9); ctx.lineTo(-6, 14); ctx.lineTo(2, 10); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#c8d8e0';
        ctx.beginPath(); ctx.arc(11, -2, 7, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b2d42';
        ctx.beginPath(); ctx.arc(13, -3, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(17, -1, 1.8, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#8a9aa8';
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(15, 1); ctx.lineTo(21, 2);
        ctx.moveTo(15, 2); ctx.lineTo(21, 5);
        ctx.moveTo(15, 3); ctx.lineTo(20, 7);
        ctx.stroke();
    } else if (type === 'scarab') {
        ctx.strokeStyle = '#2b2d42';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(-7, -2); ctx.lineTo(-12, 4);
        ctx.moveTo(-2, 1); ctx.lineTo(-7, 7);
        ctx.moveTo(3, 1); ctx.lineTo(8, 7);
        ctx.moveTo(8, -2); ctx.lineTo(13, 4);
        ctx.stroke();
        ctx.fillStyle = '#3a8a9a';
        ctx.beginPath(); ctx.ellipse(0, 0, 11, 8, 0, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fbd000';
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(0, 8); ctx.stroke();
        ctx.fillStyle = '#fbd000';
        ctx.beginPath(); ctx.arc(-5, -3, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(5, -3, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#2b6a7a';
        ctx.beginPath(); ctx.arc(11, 0, 5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath();
        ctx.moveTo(14, -3); ctx.lineTo(19, -7); ctx.lineTo(18, 0); ctx.closePath(); ctx.fill();
        ctx.beginPath();
        ctx.moveTo(14, 3); ctx.lineTo(19, 7); ctx.lineTo(18, 0); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#fbd000';
        ctx.beginPath(); ctx.arc(12, -2, 1.8, 0, Math.PI * 2); ctx.fill();
    }
}


// --- Theme goal buildings (paper style) ---
function drawGoal(type, c) {
    if (type === 'house') {
        ctx.fillStyle = '#f8edeb';
        ctx.fillRect(c.x, c.y + 38, c.width, c.height - 38);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.strokeRect(c.x, c.y + 38, c.width, c.height - 38);

        ctx.fillStyle = '#e88b62';
        ctx.beginPath();
        ctx.moveTo(c.x - 14, c.y + 42);
        ctx.lineTo(c.x + c.width / 2, c.y - 72);
        ctx.lineTo(c.x + c.width + 14, c.y + 42);
        ctx.fill();

        ctx.fillStyle = '#5cc8e8';
        ctx.fillRect(c.x + 28, c.y + 78, 42, 42);
        ctx.fillRect(c.x + c.width - 70, c.y + 78, 42, 42);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 4;
        ctx.strokeRect(c.x + 28, c.y + 78, 42, 42);
        ctx.strokeRect(c.x + c.width - 70, c.y + 78, 42, 42);

        ctx.fillStyle = '#7b4b3a';
        ctx.beginPath();
        ctx.roundRect(c.x + c.width / 2 - 32, c.y + c.height - 92, 64, 92, [30, 30, 0, 0]);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2 + 18, c.y + c.height - 46, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#67a85d';
        ctx.fillRect(c.x + c.width - 24, c.y - 25, 10, 48);
        ctx.fillStyle = '#e8c34f';
        ctx.beginPath();
        ctx.arc(c.x + c.width - 19, c.y - 30, 18, 0, Math.PI * 2);
        ctx.fill();
    } else if (type === 'mine') {
        ctx.fillStyle = '#4a3a2a';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2, c.y + c.height - 40, 70, Math.PI, 0);
        ctx.rect(c.x + c.width / 2 - 70, c.y + c.height - 40, 140, 40);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.stroke();
        ctx.strokeStyle = '#8a5a33';
        ctx.lineWidth = 10;
        ctx.beginPath();
        ctx.moveTo(c.x + c.width / 2 - 78, c.y + c.height - 40);
        ctx.lineTo(c.x + c.width / 2 - 78, c.y + 20);
        ctx.lineTo(c.x + c.width / 2 - 34, c.y + 20);
        ctx.moveTo(c.x + c.width / 2 + 78, c.y + c.height - 40);
        ctx.lineTo(c.x + c.width / 2 + 78, c.y + 20);
        ctx.lineTo(c.x + c.width / 2 + 34, c.y + 20);
        ctx.stroke();
        ctx.fillStyle = '#8a5a33';
        ctx.fillRect(c.x + c.width / 2 - 90, c.y + c.height - 24, 180, 12);
        ctx.fillStyle = '#FFD23F';
        ctx.font = 'bold 26px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⛏', c.x + c.width / 2, c.y + 28);
    } else if (type === 'cave') {
        ctx.fillStyle = '#5a4a3a';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2, c.y + c.height - 40, 80, Math.PI, 0);
        ctx.rect(c.x + c.width / 2 - 80, c.y + c.height - 40, 160, 40);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.stroke();
        ctx.fillStyle = '#453a2e';
        for (let i = 0; i < 5; i++) {
            const sx = c.x + 30 + i * 42;
            ctx.beginPath();
            ctx.moveTo(sx, c.y + 10);
            ctx.lineTo(sx + 7, c.y + 46);
            ctx.lineTo(sx + 14, c.y + 10);
            ctx.fill();
        }
        ctx.fillStyle = '#ffffff';
        ctx.font = '30px "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('✨', c.x + c.width / 2, c.y + 40);
    } else if (type === 'arch') {
        ctx.fillStyle = '#7ac8e8';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2, c.y + c.height - 30, 84, Math.PI, 0);
        ctx.rect(c.x + c.width / 2 - 84, c.y + c.height - 30, 168, 30);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.stroke();
        ctx.fillStyle = '#2a9a5a';
        for (let i = 0; i < 4; i++) {
            ctx.beginPath();
            ctx.arc(c.x + 24 + i * 46, c.y + c.height - 30, 12, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.fillStyle = '#ff6f91';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2, c.y + 24, 10, 0, Math.PI * 2);
        ctx.arc(c.x + c.width / 2 - 30, c.y + 16, 8, 0, Math.PI * 2);
        ctx.arc(c.x + c.width / 2 + 30, c.y + 16, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = '30px "Segoe UI Emoji", "Noto Color Emoji", sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🐚', c.x + c.width / 2, c.y + 38);
    } else if (type === 'hut') {
        ctx.fillStyle = '#d8a868';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2, c.y + c.height - 30, 78, Math.PI, 0);
        ctx.lineTo(c.x + c.width / 2 - 78, c.y + c.height);
        ctx.lineTo(c.x + c.width / 2 + 78, c.y + c.height);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.stroke();
        ctx.fillStyle = '#8a5a33';
        ctx.beginPath();
        ctx.moveTo(c.x + c.width / 2, c.y + 10);
        ctx.lineTo(c.x + c.width / 2 - 90, c.y + 60);
        ctx.lineTo(c.x + c.width / 2 + 90, c.y + 60);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#4a3a2a';
        ctx.beginPath();
        ctx.roundRect(c.x + c.width / 2 - 28, c.y + c.height - 78, 56, 78, [24, 24, 0, 0]);
        ctx.fill();
    } else if (type === 'torii') {
        const tcx = c.x + c.width / 2;
        const tBase = c.y + c.height;

        ctx.fillStyle = '#e52521';
        ctx.beginPath();
        ctx.moveTo(tcx - 54, c.y + 34);
        ctx.lineTo(tcx - 38, c.y + 34);
        ctx.lineTo(tcx - 42, tBase);
        ctx.lineTo(tcx - 64, tBase);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(tcx + 54, c.y + 34);
        ctx.lineTo(tcx + 38, c.y + 34);
        ctx.lineTo(tcx + 42, tBase);
        ctx.lineTo(tcx + 64, tBase);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.roundRect(tcx - 60, c.y + 40, 120, 16, 8);
        ctx.fill();

        ctx.fillRect(tcx - 6, c.y + 24, 12, 22);

        ctx.beginPath();
        ctx.roundRect(tcx - 80, c.y + 2, 160, 22, 11);
        ctx.fill();
        ctx.beginPath();
        ctx.roundRect(tcx - 88, c.y + 4, 12, 16, 6);
        ctx.fill();
        ctx.beginPath();
        ctx.roundRect(tcx + 76, c.y + 4, 12, 16, 6);
        ctx.fill();

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(tcx - 54, c.y + 34);
        ctx.lineTo(tcx - 38, c.y + 34);
        ctx.lineTo(tcx - 42, tBase);
        ctx.lineTo(tcx - 64, tBase);
        ctx.closePath();
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(tcx + 54, c.y + 34);
        ctx.lineTo(tcx + 38, c.y + 34);
        ctx.lineTo(tcx + 42, tBase);
        ctx.lineTo(tcx + 64, tBase);
        ctx.closePath();
        ctx.stroke();
    } else if (type === 'igloo') {
        const icx = c.x + c.width / 2;
        const iBase = c.y + c.height;

        ctx.fillStyle = '#e8f4fc';
        ctx.beginPath();
        ctx.arc(icx, iBase, 92, Math.PI, 0);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = '#a0c8e0';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(icx, iBase, 64, Math.PI, 0);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(icx, iBase, 36, Math.PI, 0);
        ctx.stroke();
        for (let i = 0; i < 5; i++) {
            const a = Math.PI + ((i + 1) * Math.PI) / 6;
            ctx.beginPath();
            ctx.moveTo(icx + Math.cos(a) * 40, iBase + Math.sin(a) * 40);
            ctx.lineTo(icx + Math.cos(a) * 92, iBase + Math.sin(a) * 92);
            ctx.stroke();
        }

        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(icx, iBase, 92, Math.PI, 0);
        ctx.stroke();

        ctx.fillStyle = '#2b2d42';
        ctx.beginPath();
        ctx.roundRect(icx - 26, iBase - 62, 52, 62, [26, 26, 0, 0]);
        ctx.fill();
    } else if (type === 'pyramid') {
        ctx.fillStyle = '#e8c878';
        ctx.beginPath();
        ctx.moveTo(c.x + c.width / 2, c.y + 10);
        ctx.lineTo(c.x - 30, c.y + c.height);
        ctx.lineTo(c.x + c.width + 30, c.y + c.height);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.stroke();
        ctx.fillStyle = '#c89848';
        ctx.beginPath();
        ctx.moveTo(c.x + c.width / 2, c.y + 10);
        ctx.lineTo(c.x + c.width + 30, c.y + c.height);
        ctx.lineTo(c.x + c.width + 60, c.y + c.height - 40);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#a87830';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(c.x + 30, c.y + c.height - 40);
        ctx.lineTo(c.x + c.width - 30, c.y + c.height - 40);
        ctx.moveTo(c.x + 60, c.y + c.height - 78);
        ctx.lineTo(c.x + c.width - 60, c.y + c.height - 78);
        ctx.stroke();
        ctx.fillStyle = '#4a3a2a';
        ctx.beginPath();
        ctx.roundRect(c.x + c.width / 2 - 26, c.y + c.height - 70, 52, 70, [24, 24, 0, 0]);
        ctx.fill();
        ctx.fillStyle = '#fbd000';
        ctx.beginPath();
        ctx.arc(c.x + c.width / 2, c.y + c.height - 40, 6, 0, Math.PI * 2);
        ctx.fill();
    } else if (type === 'submarine') {
        const scx = c.x + c.width / 2;
        const sBase = c.y + c.height;

        ctx.fillStyle = '#2b6a9a';
        ctx.fillRect(scx - 8, c.y + 8, 16, 70);
        ctx.beginPath();
        ctx.roundRect(scx - 14, c.y - 8, 28, 20, 8);
        ctx.fill();

        ctx.fillStyle = '#4fc3f7';
        ctx.beginPath();
        ctx.ellipse(scx, sBase - 44, 96, 44, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 5;
        ctx.stroke();

        ctx.fillStyle = '#2b6a9a';
        ctx.beginPath();
        ctx.ellipse(scx, sBase - 26, 96, 16, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFD23F';
        [[-48, -52], [0, -44], [48, -52]].forEach(([ox, oy]) => {
            ctx.beginPath();
            ctx.arc(scx + ox, sBase + oy, 11, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 3;
            ctx.stroke();
        });

        ctx.fillStyle = '#2b6a9a';
        ctx.beginPath();
        ctx.roundRect(scx - 24, sBase - 88, 48, 24, 8);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(scx + 88, sBase - 70);
        ctx.lineTo(scx + 118, sBase - 58);
        ctx.lineTo(scx + 84, sBase - 34);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#FFD23F';
        ctx.beginPath();
        ctx.arc(scx + 112, sBase - 52, 7, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = 'rgba(255,255,255,0.8)';
        [[-20, -96], [6, -104], [28, -92]].forEach(([ox, oy]) => {
            ctx.beginPath();
            ctx.arc(scx + ox, sBase + oy, 5 + ((ox % 3) + 1), 0, Math.PI * 2);
            ctx.fill();
        });
    }
}

let paused = false;

function setPaused(p) {
    if (p === paused) return;
    paused = p;
    if (!p) requestAnimationFrame(loop);
}

function loop() {
    if (paused) return;
    update();
    draw();
    requestAnimationFrame(loop);
}

document.addEventListener('visibilitychange', () => setPaused(document.hidden));
window.addEventListener('blur', () => setPaused(true));
window.addEventListener('focus', () => setPaused(false));

document.getElementById('modal-btn').addEventListener('click', nextLevel);

// --- Character picker (task 90): choose a hero before the world loads ---
let gameStarted = false;
function chooseCharacter(id) {
    if (gameStarted) return;
    gameStarted = true;
    selectedCharacter = id;
    document.getElementById('char-modal').classList.remove('show');
    loadExplorerFrames();
    loadWorld();
    loop();
}
document.querySelectorAll('.char-btn').forEach(btn => {
    btn.addEventListener('click', () => chooseCharacter(btn.dataset.character));
});

// Start Game — wait for the character picker
document.getElementById('char-modal').classList.add('show');
